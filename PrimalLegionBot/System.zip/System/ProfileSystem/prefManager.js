const fs = require('fs');

//for this file to work as intended it must be required to a global variable in app.js


var person = {
    id: "01",
    points: 0
};

//checks if user has a profile
module.exports.setUp = (async(member) =>{
    let filename = member.id + ".json";
    
    if (!fs.existsSync('System/Data/001/' + filename)) {  
    var profile = {
        id: member.id,
        points: 0
    };
    let data = JSON.stringify(profile, null, 2);
    fs.writeFile('System/Data/001/' + filename, data, (err) => {          
        if (err) throw err;
        console.log('Data written to file');
        });
        console.log("generating empty profile for " + member.displayName); 
    }
    //This will trim extra values if some are removed over time
    //Also if properties are added in the future this section will be used to add new feilds to existing accounts.
    else
    { 
        try{
        if(!member.bot)
        {
        let loadedProfile = await global.PrefSys.LoadFile(member);
        let foundKeys = Object.keys(loadedProfile);
        let expectedKeys = Object.keys(person);
        let fileChanged = false;
        foundKeys.forEach(element => {
            if(!expectedKeys.includes(element))
            {
                delete loadedProfile[element];
                fileChanged = true;
            }
        }); 

        if(fileChanged)
        {
            let data = JSON.stringify(loadedProfile, null, 2);
            fs.writeFile('System/Data/001/' + filename, data, (err) => {          
                if (err) throw err;
                console.log("Correcting profile of " + member.displayName); 
                });
                
    
                }
            }

        }
        catch(e)
        {
            
        }
    }
    
});

module.exports.UpdateFile = (async(member, object)=>{
    let filename = member.id + ".json";
    let data = JSON.stringify(object, null, 2);
    fs.writeFile('System/Data/001/' + filename, data, (err) => {          
        if (err) throw err;
        console.log(filename + ' updated');
        
        });
});

module.exports.LoadFile = (async(member)=>{
    let filename = member.id + ".json"; 
    try{

        if(fs.existsSync('System/Data/001/' + filename))
         {
            let filePath = 'System/Data/001/' + filename;
            let object = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            return object;
        }
    }
    catch(exception)
    {
        console.log("failed to load, no file found " + filename);
        //global.PrefSys.setUp(member);
        return null;
    }
});

module.exports.CreateLog = (async(log)=>{
    
    let date = Date.now();
    let cdate = new Date(date);

    let filename = String(cdate.getFullYear()) + "-" + String(cdate.getMonth()) + "-" + String(cdate.getDate()) + ".txt";
    if(fs.existsSync('System/Data/logs/' + filename))
    {
        fs.appendFile('System/Data/logs/' + filename, log + '\r\n', (err) => {          
            if (err) throw err;
            });
    }
    else
    {
        fs.writeFile('System/Data/logs/' + filename, log + '\r\n', (err) => {          
            if (err) throw err;
            });
    }

   
});
